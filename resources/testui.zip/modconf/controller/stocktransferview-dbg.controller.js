sap.ui.define([
    "core/generic/genericlistview"
],

    function (genericlistview) {
        "use strict";

        return genericlistview.extend("modconfcontroller.stocktransferview", {

            onInit: function () {
                genericlistview.prototype.onInit.apply(this, arguments);

            },
            onBeforeShow: function (oEvent) {
                //this.validateAccess();
                this.initialize();

            },
            initialize: async function () {
                this.setPageId("stocktransferlv");
                this.setFormTitle("Stock Transfer View");
                this.setBackwardRoute("LandingPageIndex");

                this.setListViewDataSourceProperties("GET", "/odata/v4/inventory-transfer-sap/InventoryTransferSAPHead?$orderby=PostDate desc", "", "value");
                this.setListViewDisplayColumns(["Inspection Lot", "Material Code", "Plant", "Status", "Post Date", "action"]);
                this.setListViewDataColumns(["InspectionLot", "Material", "Plant", "Status", "PostDate", "Edit"]);

                this.setFormSubTitle("Result List");
                this.setListViewFilterColumn("stglvInspectionLot", "Inspection Lot", "Cfl", "eq", "String", "InspectionLot", "cflForInspectionLot");
                this.setListViewFilterColumn("stglvMaterial", "Material", "Cfl", "eq", "String", "Material", "cflForMaterial");
                this.setListViewEditProperty("ID");
                this.setForwardRoute("RouterNameStockTransferEntryForm");
                //this.setBackwardRoute("RouteIndex");
                await this.showListView(this.getPageId());
            },
            cflForInspectionLot: async function () {
                this.setCflTitle('Inspection Lot List');
                await this.createNewModelUsingAPI("GET", "/odata/v4/inventory-transfer-sap/InventoryTransferSAPHead", "", this.getCflListViewDataSourceModelName());
                this.setCflDisplayColumns(["Inspection Lot"]);
                this.setCflDataColumns(["InspectionLot"]);
                this.setCflValueAndDisplay("", "", "stglvInspectionLot", "InspectionLot");
                this.showCfl("stglvInspectionLot", this.getCflListViewDataSourceModelName(), "value", this.onClosecflForInspection.bind(this));
            },
            onClosecflForInspection: function () {
                let x = this.getCflObject();
            },
            cflForMaterial: async function () {
                this.setCflTitle('Material List');
                await this.createNewModelUsingAPI("GET", "/odata/v4/inventory-transfer-sap/InventoryTransferSAPHead", "", this.getCflListViewDataSourceModelName());
                this.setCflDisplayColumns(["Material"]);
                this.setCflDataColumns(["Material"]);
                this.setCflValueAndDisplay("", "", "stglvMaterial", "Material");
                this.showCfl("stglvMaterial", this.getCflListViewDataSourceModelName(), "value", this.onClosecflForMaterial.bind(this));
            },
            onClosecflForMaterial: function () {
                let x = this.getCflObject();
            }
        });
    });
