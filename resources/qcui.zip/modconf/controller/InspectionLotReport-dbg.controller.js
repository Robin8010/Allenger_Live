

sap.ui.define([
	  "core/generic/genericentryform",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], 
 function (genericentryform, MessageToast, MessageBox, Controller) {
	"use strict";
// Paste ABOVE your Controller.extend line
var NOTO_SANS_BASE64 = "PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ZW4+CiAgPG1ldGEgY2hhcnNldD11dGYtOD4KICA8bWV0YSBuYW1lPXZpZXdwb3J0IGNvbnRlbnQ9ImluaXRpYWwtc2NhbGU9MSwgbWluaW11bS1zY2FsZT0xLCB3aWR0aD1kZXZpY2Utd2lkdGgiPgogIDx0aXRsZT5FcnJvciA0MDQgKE5vdCBGb3VuZCkhITE8L3RpdGxlPgogIDxzdHlsZT4KICAgICp7bWFyZ2luOjA7cGFkZGluZzowfWh0bWwsY29kZXtmb250OjE1cHgvMjJweCBhcmlhbCxzYW5zLXNlcmlmfWh0bWx7YmFja2dyb3VuZDojZmZmO2NvbG9yOiMyMjI7cGFkZGluZzoxNXB4fWJvZHl7bWFyZ2luOjclIGF1dG8gMDttYXgtd2lkdGg6MzkwcHg7bWluLWhlaWdodDoxODBweDtwYWRkaW5nOjMwcHggMCAxNXB4fSogPiBib2R5e2JhY2tncm91bmQ6dXJsKC8vd3d3Lmdvb2dsZS5jb20vaW1hZ2VzL2Vycm9ycy9yb2JvdC5wbmcpIDEwMCUgNXB4IG5vLXJlcGVhdDtwYWRkaW5nLXJpZ2h0OjIwNXB4fXB7bWFyZ2luOjExcHggMCAyMnB4O292ZXJmbG93OmhpZGRlbn1pbnN7Y29sb3I6Izc3Nzt0ZXh0LWRlY29yYXRpb246bm9uZX1hIGltZ3tib3JkZXI6MH1AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc3MnB4KXtib2R5e2JhY2tncm91bmQ6bm9uZTttYXJnaW4tdG9wOjA7bWF4LXdpZHRoOm5vbmU7cGFkZGluZy1yaWdodDowfX0jbG9nb3tiYWNrZ3JvdW5kOnVybCgvL3d3dy5nb29nbGUuY29tL2ltYWdlcy9icmFuZGluZy9nb29nbGVsb2dvLzF4L2dvb2dsZWxvZ29fY29sb3JfMTUweDU0ZHAucG5nKSBuby1yZXBlYXQ7bWFyZ2luLWxlZnQ6LTVweH1AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4tcmVzb2x1dGlvbjoxOTJkcGkpeyNsb2dve2JhY2tncm91bmQ6dXJsKC8vd3d3Lmdvb2dsZS5jb20vaW1hZ2VzL2JyYW5kaW5nL2dvb2dsZWxvZ28vMngvZ29vZ2xlbG9nb19jb2xvcl8xNTB4NTRkcC5wbmcpIG5vLXJlcGVhdCAwJSAwJS8xMDAlIDEwMCU7LW1vei1ib3JkZXItaW1hZ2U6dXJsKC8vd3d3Lmdvb2dsZS5jb20vaW1hZ2VzL2JyYW5kaW5nL2dvb2dsZWxvZ28vMngvZ29vZ2xlbG9nb19jb2xvcl8xNTB4NTRkcC5wbmcpIDB9fUBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKC13ZWJraXQtbWluLWRldmljZS1waXhlbC1yYXRpbzoyKXsjbG9nb3tiYWNrZ3JvdW5kOnVybCgvL3d3dy5nb29nbGUuY29tL2ltYWdlcy9icmFuZGluZy9nb29nbGVsb2dvLzJ4L2dvb2dsZWxvZ29fY29sb3JfMTUweDU0ZHAucG5nKSBuby1yZXBlYXQ7LXdlYmtpdC1iYWNrZ3JvdW5kLXNpemU6MTAwJSAxMDAlfX0jbG9nb3tkaXNwbGF5OmlubGluZS1ibG9jaztoZWlnaHQ6NTRweDt3aWR0aDoxNTBweH0KICA8L3N0eWxlPgogIDxhIGhyZWY9Ly93d3cuZ29vZ2xlLmNvbS8+PHNwYW4gaWQ9bG9nbyBhcmlhLWxhYmVsPUdvb2dsZT48L3NwYW4+PC9hPgogIDxwPjxiPjQwNC48L2I+IDxpbnM+VGhhdOKAmXMgYW4gZXJyb3IuPC9pbnM+CiAgPHA+VGhlIHJlcXVlc3RlZCBVUkwgPGNvZGU+L3Mvbm90b3NhbnMvdjM2L28tMElJcFFseDNRVWxDNUE0UE5iNVEudHRmPC9jb2RlPiB3YXMgbm90IGZvdW5kIG9uIHRoaXMgc2VydmVyLiAgPGlucz5UaGF04oCZcyBhbGwgd2Uga25vdy48L2lucz4K";
    let ReportHeader_Y;
let PageHeader_Y;
let Line_Y;
let Footer_Y;
let Total=0;
let Quantity=0;
let Sgst=0;
let cgst=0;
let Igst=0;
let _LineTotal=0;
        return genericentryform.extend("modconfcontroller.InspectionLotReport", {

            onInit: function () {
                genericentryform.prototype.onInit.apply(this, arguments);
                debugger;
            },
            onBeforeShow: async function (oEvent) {
                this.isValidUser();
                await  this.FillListView();
                debugger;
                this.initialize();

            },
            initialize: async function () {
                debugger;
                    let oPath = jQuery.sap.getModulePath(
                    "qcui",
                    "/modconf/model/InspectionLotReport.json", // Edit Response Model
                );
                let oModel = new sap.ui.model.json.JSONModel(oPath);
                this.getView().setModel(oModel, this.getEntryFormDataSourceModelName());

                 this.setListViewFilterColumn("stglvSerial", "SerialNumber", "Cfl", "eq", "String", "SerialNumber", "cflForSerial");
            },
            _loadNotoSansFont: function () {
                return fetch("https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap")
                    .then(() => {
                        // Fetch the actual TTF directly from Google Fonts CDN
                        return fetch("https://fonts.gstatic.com/s/notosans/v36/o-0IIpQlx3QUlC5A4PNb5Q.ttf");
                    })
                    .then(res => res.arrayBuffer())
                    .then(buf => {
                        const binary = String.fromCharCode(...new Uint8Array(buf));
                        return btoa(binary);
                    });
            },
             

              cflForSerial: async function () {
                try {
                    await this.createNewModelUsingAPI(
                        'GET',
                        `/odata/v4/device-group-list-report-services/DeviceGroupListReport?$format=json`,
                        '',
                        this.getCflListViewDataSourceModelName()
                    );
                    this.setCflDisplayColumns(['SerialBatchNumber']);
                    this.setCflDataColumns(['SerialBatchNumber']);
                    this.setCflValueAndDisplay('SerialBatchNumber ', 'SerialBatchNumber', '', '');

                    this.showCfl(
                        'Serial',
                        this.getCflListViewDataSourceModelName(),
                        'value',
                        this.onConfirmSerial.bind(this)
                    );
                }
                catch (error) {
                    MessageBox.show("onConfirmSerial -: " + error.message);
                }
            },
            onConfirmSerial: function () {
                debugger
                let x = this.getCflObject();
                let viewModel = this.getView().getModel(this.getEntryFormDataSourceModelName());
                viewModel.setProperty(`/SerialBatchNumber`, x.SerialBatchNumber);
               // viewModel.setProperty(`/SerialNumber`, "");
               
            },
isValidUser: function () {
                // let loginInfo=this.getLoginInfo();
                // let userid = loginInfo.UserID;

                const loginModel = this.getOwnerComponent().getModel('UserModel');
                if (!loginModel || loginModel === 'undefined') {
                    var router = sap.ui.core.UIComponent.getRouterFor(this);
                    router.navTo("RouteLogin");
                    MessageToast.show("Not a valid user.");
                }
            },

            FillListView: async function (Serial) {
                debugger;
                            // 2️⃣ Clear previous User data before fetching new one
                            if (this.getView().getModel("List")) {
                                this.getView().getModel("List").setData({ value: [] });
                            }

                            // 3️⃣ Fetch fresh data from backend
                            if(Serial!="")
                            {
                            await this.createNewModelUsingAPI(
                                "GET",
                                `/odata/v4/device-group-list-report-services/DeviceGroupListReport?$filter=SerialBatchNumber eq '${Serial}'&$format=json`,
                                
                                "",
                                "DeviceList" // keep model name same as your table binding
                            );
                        }
                        else
                        {
                             await this.createNewModelUsingAPI(
                                "GET",
                                `/odata/v4/device-group-list-report-services/DeviceGroupListReport?$format=json`,
                                
                                "",
                                "DeviceList" // keep model name same as your table binding
                            );
                        }

                            // 4️⃣ Get model reference and refresh the UI
                            const oGMCModel = this.getView().getModel("DeviceList");
                            oGMCModel.refresh(true);

			},
            onSearchWithName: function (oEvent) {
                    debugger;
			var sQuery = oEvent.getParameter("newValue"); // Get search input
			var filters=[];
			if(sQuery)
			{
				var filter1 = new sap.ui.model.Filter({path:"SupplierInvoice",operator:sap.ui.model.FilterOperator.Contains,value1:sQuery});
				filters=[filter1];
				var finalFilter = new sap.ui.model.Filter({filters:filters, and:false});
		}
		var otable = this.byId("_DebitTbl");
		otable.getBinding("items").filter(finalFilter);
    },

            Go: function (oEvent) {
                debugger;
                 const viewModel = this.getView().getModel(this.getEntryFormDataSourceModelName())
			   let Serial= viewModel.getProperty("/SerialBatchNumber");
                 this.FillListView(Serial);
                   
		},
		
        navBack: function() {
            debugger;
		//	var BPText = this.getView().byId('sideNavigation');
		//	BPText.setVisible(true);
		history.go(-1);
			
			//var router = sap.ui.core.UIComponent.getRouterFor(this);
           // router.navTo("RouteIndex");
		},
		
           
         
        async OnPrint(oEvent)
        {
             debugger;
          
            var oButton = oEvent.getSource();
					var oBindingContext = oButton.getBindingContext("DeviceList");
					let SerialBatchNumber = oBindingContext.getProperty("SerialBatchNumber");
           
           await this.createNewModelUsingAPI(
                'GET',
                 `/odata/v4/inspection-qcreport2/InspectionQcReport2?$filter=SerialBatchNumber eq '${SerialBatchNumber}'&$orderby=lineid&$top=10000`,
                '',
                'reportdata'
            );
           debugger;  
          const reportData=this.getView().getModel('reportdata').getData();
          
          const { value = [] } = reportData || {};
            let material=value[0].Material;
            let ManufacturingOrder=value[0].ManufacturingOrder;

            //#endregion device 
             await this.createNewModelUsingAPI(
                                "GET",
                               `/odata/v4/device-group-list-report-services/DeviceGroupListReport?$filter=SerialBatchNumber eq '${SerialBatchNumber}'&$format=json`,
                                
                                "",
                                "DeviceListForreport" // keep model name same as your table binding
                            );
                            const DeviceListForreport=this.getView().getModel('DeviceListForreport')
            //#endregion
            //#endregion production orderposting date 
             await this.createNewModelUsingAPI(
                "GET",
                `/sap/opu/odata/sap/API_PRODUCTION_ORDER_2_SRV/A_ProductionOrder_2?$filter=ManufacturingOrder eq '${ManufacturingOrder}'&$format=json`,
                
                "",
                "ManufacturingOrder" // keep model name same as your table binding
            );
            const production=this.getView().getModel('ManufacturingOrder')
           // const partModel=this.getView().getModel('PartData')
          const productionData=production.getProperty("/d/results");
            //#endregion

          //GetPartNo Info
           await this.createNewModelUsingAPI(
                'GET',
                 `/sap/opu/odata/sap/ZUNE_SB_P_C_V3/ZUNE_C_PRODUCT_FINAL?$filter=PartCode eq '${material}'`,
                '',
                'PartData'
            );
           debugger;  
          const partModel=this.getView().getModel('PartData')
          const PartData=partModel.getProperty("/d/results");

          
          if(PartData.length>0)
          {
                        debugger;
                        //GetPartNo Info
                        debugger;
                            // Use jsPDF
                                const { jsPDF } = window.jspdf;
                            const doc = new jsPDF({
                            orientation: "portrait", // 👈 change from portrait
                            unit: "mm",
                            format: "a4"
                            });
                        // ✅ Font loaded from embedded variable — no fetch, no async, no error
                        doc.addFileToVFS("NotoSans-Regular.ttf", NOTO_SANS_BASE64);
                        doc.addFont("NotoSans-Regular.ttf", "NotoSans", "normal");
                        doc.setFont("NotoSans");
                        doc.setFontSize(7); // reset your default size after font change

                            const oModel = this.getView().getModel('reportdata'); // original model
                const data = oModel.getProperty("/value");

               

                // Set model
                //this.getView().setModel(oDistinctModel, "distinctModel");
                //const tData=this.getView().getModel('distinctModel');
                debugger;
                    //const oGMCModel = this.getView().getModel("DeviceList");
                    const value1=    DeviceListForreport.getProperty("/value");

debugger
                            const reportHeaderY = this.ReportHeader(doc, value,PartData,productionData);
                            const lineStartY    = this.PageHeader(doc, value, reportHeaderY);

                            // ===== LINE ITEMS (AUTO PAGE BREAK) =====
                        const DevicesY= this.LineSection(doc, value, lineStartY);

                        const DeviceHeaderLineY= this.DeviceHeader(doc, value, DevicesY);
                        debugger
                        const DeviceLineSection= this.DeviceLineSection(doc, value1, DeviceHeaderLineY,value);
                        this.foooter(doc, value,productionData, DeviceLineSection);

                        const pageCount = doc.getNumberOfPages();
 doc.setFontSize(8);
                        for (let i = 1; i <= pageCount; i++) {
                            doc.setPage(i);
                             doc.setFontSize(10);
                               doc.setFont("Arial", "normal");
                               doc.setTextColor(0, 0, 0);
                            doc.text(
                                `Page ${i} of ${pageCount}`,
                                180,              // X position (center-ish)
                                doc.internal.pageSize.height - 10 // bottom of page
                            );
                              doc.text(
                               "This report is electronically authenticated and no signature is required",
                                50,              // X position (center-ish)
                                doc.internal.pageSize.height - 15 // bottom of page
                            );
                              doc.setFontSize(16);
                               doc.setFont("Arial", "bold");
                               doc.setTextColor(255, 0, 0); // Red
                              doc.text(
                               "CONTROLLED COPY",
                                80,              // X position (center-ish)
                                doc.internal.pageSize.height - 10 // bottom of page
                            );
                            doc.setTextColor(0, 0, 0);
                        }

                    doc.setFontSize(10);
                    doc.save("SimpleReport.pdf");
                }
                else
                {
                    MessageBox.show("Item details npt exist...");
                }
        },

         ReportHeader: function (doc, value,PartData,productionData) {
    debugger;
            let y = 10;

    doc.setFont("Arial", "bold");
    doc.setFontSize(10);
  
    doc.line(5, y , doc.internal.pageSize.getWidth() - 5, y);/// Horijontal line1
    doc.line(5, y+15 , doc.internal.pageSize.getWidth() - 5, y+15);/// Horijontal line2
    //Create 3 horijontal section
    doc.line(70, y, 70, y+15); ////Line vartival
    doc.line(140, y, 140, y+15); ////Line vartival
     doc.setFont("Arial", "normal");
       doc.setFontSize(7);
       
    doc.text(`${value[0].ISO|| ""}`, 145, y+10);
    doc.line(140, y+7.5 , doc.internal.pageSize.getWidth() - 5, y+7.5);/// Horijontal line3 for third section

    doc.setFont("Arial", "bold");
     doc.setFontSize(14);
    doc.text(`${value[0].InspectionPlanDesc|| ""}`, doc.internal.pageSize.getWidth()/2, y+20, {
        align: "center"
    });

    ///////
     doc.setFont("Arial", "normal");
   
     //let Image="iVBORw0KGgoAAAANSUhEUgAAARcAAABSCAYAAAB+MZC/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnRpZmY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vdGlmZi8xLjAvIj48dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPjwvcmRmOkRlc2NyaXB0aW9uPjwvcmRmOlJERj48L3g6eG1wbWV0YT4NCjw/eHBhY2tldCBlbmQ9J3cnPz4slJgLAABFWklEQVR4Xu2dd5glRbn/P9Xx5DM5z2zOy7IEWfKSUUQkCQYwgooBlZ+XyzWjKIhwVUx4UUERkKBEJUhmWWBh2QCb2TyzM7OTTz6nQ/3+6HNmZ2bPpIXl6t35PM88z26f7urq6qpvv/XWW1VCSimZYIIJJniHUYYeeLeQrjv0UFEmtG+CCf49Ee+25SJdF6F4mtaezPJ61sSyLfpyEkWArkCloWJqCqa0OaxEH5rEviElCDH06Ki4rouSz+94kFIi9uF+E0zwf4V3VVwKDW5FV5o2afJce5Jl7XG6LejOOSgIDBVqfRoluqAmYHDZ9AgLo+rQpMbFwIb+jw4HZ4jVpAgoNRR0ISgURhqFg4wcZX6Dtnia13N+LNvqN/V0RVBuKP3nF7BQOCaa/88+CtoEE/xf4F0VF4CWlMVJL8XZ2N4LLqgKOAgY2AYdiVAF80sNbARr31s34Md9I2c7PNgF33u9lbQz+DdVQL1fxVQELuBKCKnwnuow35oV5L5dWX60uoMuS6LmxcKnCpoCKs6Q0hNS8qk51ZxTIfFpb08UJ5jg35l3TVwK1sPHVyZ5eEsnccv1RGUUwppC7LymoYfHzZYMfG1ZGw/vTCOL9XIGGjOupC6q0xjQ+NSUEJODGu99stVToYEUcRspwutKvXjGZI4umxCXCQ5cijWzd568sPRkbbZ1p+jNSdwxCAsMNmjeFq5La1YiVeEpwNA/bcCfKigzFOp8KnV+FUXkVWPo38Br8n+uKkBXMcW7otkTTPAvy7sjLkKQsF0WPNPDko4EisJevopiKAKCumBlb25M54/GHo/K6LgSIrogoAp0IcaW4bwvxlCGdPMmmOAA5N0RF+DTr8eIJVOIfMMdC7oQzA7rfOX1bqwiXZDxoAqI6mN7XKEK1nZlWdKZJawpZBw5NrGQMC+ic3CJgX9oF2qCCQ4wxtba3gbNKZuY5bKlJ0XMHnt3CCDrSp7ryLCkM+O13LeBKiCgjf1xFUPh67OiHFFusi6WQ4xRLBoCGgtLjHHda4IJ/i+yX1uAI2HR0+3UP7STlX25ccjKHlzp/e3LtQNRgIAqRhcpCRFdocan4uTPVQcMUY+IgEd2JGhOO6jFvL0TTHAAsV/F5awlu+nJ2CQsiSNHbdbDognos/b1ag9FeP6TUTPhSqaHNE6s8jE5kA/gG+2aPLoKuqnw+yMqaPSrXpzLBBMcoOxXcVnWlSU9Vn/FMKgCjqv0ccHS3fS+DYFRBAS0MWREFSzvyLK610If54jPEaUmR5eZe2yWiQC6CQ5g9pu4lN2/g67skGi1fcCR8FJXlpe6sthvwxKQ+bTGhCa4ZEYpp9UG8v8fwxQECUeVmxxb4Ztw5k4wwf4Ql7QjOWfJbvosd6y9iVHJOJKMLQm+jUbrSkjao+dIU/CGkseLgBs3xMg4Evl2TLW3yT7FRO7LNRO8OxR7N8WOFWOs5w1hn+pQEfZLhK5573ZyYx1vHiPnNwTQFcGvDy+nZIxDygNpybhc8XoX9+xIDN9dcSVTIzplhsrlc8q5uMEA4KbNab7yWvvQsweTf9wV76tnYXQMls6+MMa5Ss1ph++t6ePB7Ym9o4oBQxUcU+51365ZUMrskDY47THeZ38y3omf4z2/wL5e189Yymos5wxhYL5WdGe4pyVDwnI5vlznQ5PCe50z4MJB93qwOckDrRm2JCy2JW1S1h43hZDg1wVNAY16v8bCEp2wpvDFGeG90tkX3hlxGZCRxkeaaU7aQ89429T5VQSw7LR66nzjF5fmjMvlr3Vyf3NqeB+Q5XLelBAzQjqnNUY4MR++P5q4CKAmn7/XT6+n2hxj/oZ5gTdsiBPP7elSxhzJd+dGKDH2nk5QrIJtS0uuXt3FbZvjRcVF4FlnhiJwhMI/F1dxdLknpAXeimX5w/YMWcdle8ohZrlsT1nkpGRBxEQVAktKHj62cs9FwzzPvnL39jjrEi5bkxYdWYkrJZWmQmNAw8gHSbtCcFBI4bwmr8GNhaFl9lJHmqvWxGlNWaTtkX2E86IGh5ca5CR8c3aY6IB3MjTdgeXRl3O4Zn2CjoxNo18lnP9AXjk7sud8Bq8a8KuNvVy/KUXWdknaDraEap/KrIjBrLDOTYeUDrq2wMUvd/JsZ5agKujM2KQciS0ltrv32IQAVEWg4AWNzg7rTAnp/GlRxZAzx887Iy5AZ9bhshW93Lc9PvSndwQBSFeSvXCy120ZZ0Xenna55JXdPNmWGb7ySG8i5YcaAnxhfhXH5d/7aOKiCDimwocC3HNMFVUjiMvQCrgtkeOkF7pRHAehCIKawvZEbshAtqQuoONKcByXOSUGmqpx+RSTE2uCe87KV8wtKck3V3byl23FLZd+XMmkkE7Yp/PgkaVsS1hc/kYC23FxpUtHxvEqZT4cwJYSKT1hEsI7dtGUMBLBj+ZFqPHvLX7DMuT9/XZzgpe6c7zcncG2JRFDoTllk3MklrtntFEVoCmi/xUKwFQFNX4NV8IFjUEEkm/NLUxN38PAsr/lrV6u2ZDCrwpSlktH1ibres83EoYi8Kne/WsDGkFNoTkjufs9URZXez66gfd5K2Fz3YYET7Yl6c06WK5EyzdmgBkRg482BRGKwmcm+QjpKjes6+X3OzK0JHMkLHdwnoSXh8PKTJaeXNN/+PIVvfyjNYWuCLbGc+QGPssIVWAohiKI6AodZzcO/WncvD1xGVBB4rZk0kM76RkllFbJV0rk+B4aCRc2BakLaHxrToQycxwVGdiWdvnkS+08tzs78n1dybcWVvG9WQHUvO9lNHFRBXxxepiMI7luYTml+p4bFFsPZk1Pmq+tTRNL5ehzJFviWXKFYivyNkThcD5ZvyrQBYRNjfMbg8yIGBwaUTmq3ARgS1ryrZWd3LV1FHHJz+7WBDQGDbKOpCVlkXW8F+TdN3/9wGQG5LHUpyCA50+uZ154+HcyVFQBHCn5zzfjrO7J8WZPmoQtSTj5xjS0HAqXDj0+AFWBUkNFVwS7zmqAIve9+o0eHumw2ZHI0p2xsfPlLgA5clHtIW/cSEBRwLVdPjotyiEVAc6s1Jgd0XEdB0VVebbL5pzndtGbdRDF4qUEVJoqpgL/MbeUdXGb+3bE6co4/c1r0DV5lT2jIcDfF1fz/XUJ/t6aZFNflp5CJRqtbUm8tjuwnEX+z5VUmBod57/9ycJvT1zySyh8f2OG5a0xlvdZRR9K4Fkdar5ClQW8r0xv1i16/nA0+FWStuStDzRSpo/PetmcdDhvSTurenLD3lNTQEVw+9E1fKje7BeGO3Zk+fjLrcNOWxB45upFk4L81/wyyjTveMGSWNmT45qNKdpiWYI+ld0Zm7diWRL5ofW9KtBoDKjcIV2hVBfkFI3vzvRz2cwSNiVsvvZ6F39vTo0qLuD1vfvr2HjzkufN9zUwL5J/8CEUymF3xuab69Os60ih6AqmAiu60nRl3T3vcvTsjowrCesqsQGN46Mvd7E56RDSFV7tTBO3HK8MR3pWmW/IhYIW+S9jkfwJVxIwVE6sNJlW4ufCGpWjqoKs7Epy0fI4azrTI78H1xPAar9K3HZJ2gVhH3yOpgreU2ZSbios2Z1hTtRgS9KmPWUPW3aFtof0hm+EEFT5VEp0haguaAxouFIStyXNaYfpIZ2gpvCXo95+t2h4+30UCpqUReWvW3tY3mcVb+cSpCM5uMzkyCof9y+u4ey6AEgY/jtXnOa4zcnVPq5bH6M7ky/QMeLmR7KGRXpzjyp9Ck4+XUVReKMnw81bYrgjjDRJoC1lc1JNgKjifT0KDeqR1jSfX9nHP3b08WJXmidaEqzsypAsONaKVXAJ2NL7yyPIV/Z8uLLMX5uwXJoTNvFMjp9tSfG7bUn8Cl5M0BiLp/+LXSwvb5NCOWyKW3zo1Rj3bunmxa40L7QnebIlQXfhAzNMwx0PAtA0gTagIX/slS7+siPBq50pnm5NELfyC30Ue1aZH1aUUBtQOb0hwMm1fs5oDHBYhUmJ6Vlpe6EIkhmbTQmbTb1plse8lC2h02R6a/yMiCKQwqtDyfwHp6Bn/e9c8YTloKjBCx1Zei3JS11ZdqfsYctO4LW9yWGdY6p9hHQF6Uj8qiCsCypMlaaASqNfo8anEtUVGvwqoX0YMCnGPqVSMDW7szbnLu2gK+MUf1lAxFAImioJ26VEV5ga1PjN4eUcUqLjjHfQVoGYJdnUl6HdGZ80udIb0h4WKSnLh/170wQ8ehQfIeGgjKGCvK/Gh5rvAglF4cHmBF9c0ccr7QkytutpYf6vqAmeFxVDFZxQ6+eUen+/+SpzLkdU+mgK50d2CgiQ+eFzA8nz7Wk0RdCR9d7JiMg9fz5NYCrCq8zOON/LMBSE5Y3eLKe9FGPJrj7iuXw5sKdRvSNIL0jyA7UBjq/wuocXL+vhzm1xpJSD6mbRNym9GfjTIjrlpoIuYFJAozGgMSWoUeXzFhOT+XMHZlvimXymIlCFQM97zFRVI6oJPFf/GMiLhMCrsNJymRrVuXBSiMNKDbanbB5rS9OXdvrLUI4QNiGlpDqo9dfn6w8uY/n76vnpIWVcf3AZ35wb5ZNTwnxyaogvzYzy/YWVfHpGKV+cMdjJvK/sk7gIIWhJ5Pjsmxne6EqhDGfySci5kqAmaE67nFztZ0GJgaEIPjI5RJVf80y2saIInu/M8EBzmlI1r/CjNfo8roSkM0I3THpLXdb61EFBcNJxSDlF14Xai3i+A/+bt+L8+K00V74ZZ0c8g0AgCxVzOPIN/MzGICdU+ZgZ1pke0rl3cQN3HlvLc+9vYnFNgKAiQIjBVnY+73MjBtNCGgJ4K2GNatkFdEGZqYAAXUDWdpkc0VlQbiDtMU4xLQjU0MN5YVnVk+WUl+Js74kBAreY36GAzL8o2xO4Yfuhw5B2JJsTNjV+ha+v6uaOrX1DTxkeAZYLWRemhXVuP7KSj08J8ZlpIT4xOcR/zI7yi0PLeOWUWhqDRbp/AjYlLHanbdKaH4AZpk1NJIg9lsjwAUhXUhvQmFFmcHDU4LBSgxqfyq64xY64hdBGKMNBCOK2S5mpsCBqkHMkU4IaZ9cHOLHKx9EVPhaUGBxSarKozOC0Co33RBUOiQ75gO0j4/a5FCrN8z0uH1/Sws6kjTtMJTZVgZSSO4+q4om2FNNDOroi6LNcXtidYVl3jrg1QoMvhiM5rtrHkVVBrpzmoyIweAh1ONbGbRY90UJiuO6NLTmjMcCkgMpF00s5usSzjJ7odPjuyt283J72nDJFKGS/59wmorrC/Mda6cnatGcdXHcYK6UIqoDZYZ3FVT4uaAyCorC4Ys/zNcezdDgKX1nRxZKOjOemyFdGQxMcXmpyQVOQy2dGUO7YMmJ+pSNRVTAVwXlTS3l/jZ8SQ+HNvhyrOxM8vCtDT9bxvqYjEFC9kaNXTqtnXthrdIU68mpXhrNeTdLeF0NBUDReWwKOJ8plAa1f4DOuZFfaoT3jeD+PnA0P6Z13bIXJkt2ZUfO+FxIWlho8fWINpUbxsvv5xhjfX9NLT25AkKiE0vwI4fsaI1w/2099yLOe3uizOfTxlrFFl+e7PxqwoNSgylQ5qdqHTxHcuCHG9rg1su+mGK6kLqhR51dBwpyIztSwzq6EBYpCY0BlesSgTnVYXDdC/Mw+ULwEh6FQaVpTOb7+ehfb4zZyhEy40nvbK3qytGVc/tqc4sb1fVz9Zi9PtaVJFroK40F4f2u6U2y0xh6sJsfQLarxqVT7NK97kCffSxi2dgsgbCiEDYWoruQrQY5dKdtz7Be/rCiKEIR0BVfC4irfIGEB6MraLOvO0ZMfSSAvLGU+lUkBnRq/ysISg+vW9o1otUhXMr/MYF7U4LI55fx2QYgL6w1Or9T4TKNOWUkJDX5lTD6xKSGNGSG9v8z2OLGzfPh1T1jECMJiaILjawMcW+PHrwrq/BqHlBjMjehU+1Q0IUbXCAklhsJHJgU5pdrHq9258QtLHsuVPNqa4qGWFA80J7lje4IfrOnlK8u7uHJVD1et7qF7oLAMuK5cFxxRFeoXluZ4lqvXx7ELQ1Ij4Uoq/BozwxoBDWaUBvjYjDK+PCNCQBNsT9njFxY8a39X0ua1jiwrOrPcvjnB1at7uGVbkt9tiXPTpjg/erOH/1yX4ubtOW7enPSEZSxiOArjtlxaElm+vMHhkc3tuHKYSjOA/qFnR3qjEkr+4NtAEQLXkaw+o4GDotqYlHZNzGb+o81DD+/BlcyKGpxZ6+PDM8s5PB8+ck+rxXdX7GZ9b67oy1UEnscduG5BKZ97tYtEvksxroLNxxgsKNFJO5LPTwvTlXGRqmcNNIV1bt3cx+quNDFLekOg+S96tU9lZkjnrPoAl0wLcfSTrWzsy/U7pvdCwoywF5H5nYXVzA/mu5dSIhSFzrTFR5bHebJ5ZJFCwmemhgC4ekEZ9fngxo2xHF9ek+bZnT04UhZdK1kRntUU1hW+OC1M3HaZVx7EklBlKmRd6Mtk+fHaXjYnRgnKzHcpF1f6iOoK94wW3zMMSn4lwYaAN5oCkHElrWmH7tyACLQhL1dVvPijQ2vLuesQk5lRHwD37Xb53mu7WB+zhn8XeGlV+VQaAiq6gPryEn4/z6DE9N79d1b38YM13YjRutb7gisRrtcuy3wqpq5x9fwSLp2cn1f3Nhiz5VLYxOzJuM6ati5ch1GFhbylB57NL7V8WOXbxHVcZkZ1btuZpjOVHVlY8tpZNZynP49QBBu6srQ5Kg1k+4/vSjvsygzfPVCAUl2hXFe4a1ui3/zdl0qQcyWvdWRZ053jy6928b21vVz9Rifff6OTz7ywiyUtSeKWt7+T63hiENYFKUfSkrF5X62fuOWybrTKLGBTTw7DMKjMP6sQAqEouI5DhV/nG7PCI5drnnUxixpTGRTL8+c2yZrdfdjOMIuDSc96cvNWYV3Ez9E1YT7ZaHJpk8kHq3UuqNW5dEqIWWHPChgJVfHq2eNtaZ7tyOyTsJAfUcy6ks0xi+UdWZbn30V3dmAwjJfpoC6IGIrns5KSBVVlPLYoyMyoD9fxWobfsVkTt0d+F3iNxEGSsFxmVpVyxwIfJab30QQIBw1Kfarnn8zHubxjKHvaZU/WJZ61uOWtGPe07GkD+8qYxKVg6rancty6oZuNfTbuMI3t3aLUEKzpTPBSahSfixCkcha3bEuN6PyVgGIqfHVaiJqguWeo3XKJjeAXEsKLaIzoCo+2pUfueo2E64kFSv6tKPmKLKWXF+FVbulIXEdSE9A4qspHhaGg6zoPHFfDvKjOjetjozpCdUVgmCrfnxuhesCzAiiqSmsiy6+2JkcsL/Dys7QtTUZRCUsLgOUdSe7b2ktLyinuxM5bGVNCOk1BjevmR7ikyeScmsFd3P57j7YhnSupNL0YoxOrfOwezcoZiiyU84BjyuDF2gvvXhXQGNKZkp9/FtEVQprgsPpynjomRKVfQ7ouiqrSlshyR3Nq1HeBhEVVPur9GudMinDrAh8+TRlkjZeYBlFNoKiCg8oMSkwFfQztT7An6G70s70iyLlgKJL/Xt899OdxM8qb8/CExeKydRbLOhJoapFK826iCF7pzPH4rgx+x6vUIzWE3VKnOZZGGf4UyLfvtsJXKk9Y2xNqPhxKYZ7LKOkXRXq1oNKvUuEr/lduqlT5NeaVGRxT4wMB00Ia763ycXR9KU8eFeWgiMYLnTne6MuN7CuRUGYoVPkUOnJehguVuFCGj/RpvNYWwxt3GhmhK/xwXoSQ6YnD9dtd2pIZ1GFCE8hXukqfyuHlAS6ZHi3avxdC8Hpnis2J3PAJ5cnkYzeOrzCHMzCLI71JnCWm6mnYKEPwmiI4uMRgYYnBZ6eG+ObcKJfOKOOpI4JU+PLd87wYPhzTWdkRH0MZeqOpZ9f5uGp2xFv1cEg3/yAjy4UzK7lsVilHlRvU+VR8IxVwwciyJdMiOiWGJ1ajIjzr+cX2DGt7ckN/HTej+lwKD/qrZodfrt7Fpl4bZx/NTq8w8q2pcKBw93HVCu9rU26qfHJGGd+dYRLOV+5irE84XLS0neVd2VHv8/DiOs6s8ayh7nSOy9ekuWNT97DXaQIOL/POf7U7l3f+jpF85Z4e1qg2VZK2i1LEhHalxK8qHFNh0hTQ2JiwqPWpJKTCx+p0ZhT6+K05Ln6xlcxIk+8kzI3q+FTBLYuqOXTIbpY9GYsvv5nijo3diDF+RN56fwPTQhqb+zJ84KVe1vWkh/UPCLwuUVRX+fHBUT43Y/AcoIEN67QXe3ipNUbKcYt3r/JWmAAmBVS+MCPC117rGnu3yJHMLvWcx6qAclOjMyv2/uRKwLFQFMF7ygw0RXBytY+wppBDoUl38BmD699Nm9Ncsbx9bPUh53LpvFKumxuizDfEghswkXF3MsNN23L0Zh06HQXHHmBR5/MI+a6OK5kW1jEVuGdnkg294xhpKhLlvC+MKC6FF92XtbnglV6eaInvXWlk/pMvRheIgCr6zTmZPz2oChwJHdlxDDni3fOgMoOwCl9bUMv5VV7ft5gDckWfzclP76JnhOkGhUr/zCkNnFDpveBHuuGmVa08vSuNM8ywripgZtg7f0PcGp/1IiVRQ2VRmYmuKswt9ZEeWggCpG3jU7xhRFMRHFVh4lMV2rMuk01Jmd8Tt0fbcpzx7K5hnxG8gj+ywiSgCn56eCUL8vOBCu/6tlaXX65uZVW3hV38kfsp1NUNZ9QzLaTz1VW93LU1RmfGGTY8AQl+TXBcVYB7jizzZhUPeW87Up6f69NL21mXGCEYMD/MelqNnwa/xg8OKkHctXXUetiPI5lTanBKtY+zGkKcUjW6f2dHysavCi5Y2uEJh+vy7cPqOHXIBOWb3krzleXDz0crUGIoKMCuDzZ6I25D6/DQ/48DW8JXV3Rx5/akF1YwhnRUARWmFzC4/QPe/Kx9ZcTqI4QgbjlctCrDi7sTqEWExa8J5pUa1Ae1wphtcVxJnV9lbkRnTkRndlhjQVTnzFo/J1X5COvKWJ69H6EI3ujOsS7hsLI7TdoavvBciTepq/jPkH+HtQGNV/ossrbXb2+JpXkr6eCMUFkleBPubM9BOR484XZY0pnlrBqd6+eH+cXBUX5xcGTP34IIvzy0jBsWlvGZqWEumhziD1sSnP5cG4ufauGabZ7zMGvZvNA9BlNWSkxF4FfFoO6TEIJEzuax5jjLu3I4I9YMjxJDpcRQ+7e4XdGVpiPrDi8sePcPaYIZQYUfb0zSlnEHvbedaZer1/bx3mfbWJfYE4k6HCpQ51OZF9G9NYRGu2AAQhWs68ryVHuGiFGYEJb3fQ1hbcxiZU+Oc5fspur+HTy7K82StjQv7M6STQ9wfuavLcycHo2pQY1pIY3d2fw9iwhLb8biqR7Js505VvRa7Ixn9pwzgG1Jmzd6czzdnuGNvhyND+/kVxti9OW8SZNjQVcE00Ia86Kj+DLHwPBVKF9It7W6bOroJZ2Te48OSUmJrvCRpiCfnxbi5Do/h5UN81fuZ1bUx5SIyZSIydSIj0lhk6qAQW3QoNavY6qCsS5bK8kH1JWbkM3yTHx4T8MIKyDswXb5QL0fv5Njfdq7YFciw+4xKH7GlWRc6QWUDf1xBKQEU1M4ptrPZ2eUDP25n+6MxdqYRWvGYe5jLfzozV7W9eRIWBCx0gA81ytZ2hpDHYPCCS/Idy+xfbBbYVtvApXB4fLDEdYEEW1PHIpTZL2QoQhF0JF2uGVLgg19GS55tYsdaZflPTZvxh0OeqyFP2zoI5b/GIyUnlAEO+M2N2+Oo6sCy4WqfLDYWJB4PqNTqv3MCSl0prL9heNKydaM16VeFXO4fHkXhzzWwvLO/Dma8HbvVIeMgAqB7UrWJKxiGrUXflUQUJXixlY+H7/aBZcuaeb8JW18fUUn/7E2RUdOsrzHZnmPzYo+m7eSLt9a3cNnX+vi9OfaWfDoLtpS3jIe7li3A5SQcV2WdmVpCA7vZhgrxbtFecV0pOT05zt5qjWBGC5sW0JdQOU7c6N8bvq+z0lY1pnmjKXdxLP22Fexk2DmK/cNh1Xzhcm+vcxIKSV3t+T4yJLWvRrTIGzJWU0BpoY0Lp4c4tBSk6tWdPPjDbERrxN4+yFJKZkT0VndZ2GNNf+upD6ocX5DAAuFaw4qoat/7QXIOpJ6v8qP1vXxj5Yka2NehVXyQ68A350X5XvzS/nrzhRfXtFFa2GG7HC4ksXVfoKa4PpDKrxlEvJldsXqOD9b11X8PRdhbkRHCHj0+GoaAxrHPtXKi51jHMKUeZOywEAH5QjZH4jIX3Z6bYBHjqtiV9LizKVdrO3L5peNGJ1Ct3ZaUGVa1M8P5kXotiRdOcl/r+3ixa4c2/KTcuUwPouBfjqAh7rghpW7WNqewVFH/rKdUOVDE/DHI6uKLoL2y502N65sZWfcwlEUFJm3kIUnrv1PWYg8V0Z3TxRD4G2pg4DjKk0ePrZ66CnjZu+nYY9pduGrMZZ1plCGExZXUuFTOaXaz6s94xwCHICUkiMq/Dx9Yi1zI/rYh10EZG1vha3mVP7+QxrW+rTg8eYYymhpCkg53hYmhSVpFKX4bNOBSCBpu6RsSamhEBjegNoLoQhaUg43rYvx6/W9lN2/nfOWtHP2C22c/UIbC59opvTebfzkjR7WFra03WtUystgzHa9pQtGEha88sm4krQzwBLNX9ORHbIw0SgowuuWFO4Y1hW0sVbsgjIU/grHxng5eWd4mami5gMN64I6r5xSwyElYzfpHQnr+iz+0ZLm52u7idy3nckP7uCwR3Zw17Yk2xL2HitlACFdEDYEIX3vOmJZFt1W8eDBocQsl1h+651iNPem2ZZycFWv4bvKHmtp0CWFofOxlv8QGgPenKOPT4l4wjKeijAMxcUFuHlbhtd3x0hk3eEn7QlBxnHZGM/Rnt13cSn0B3O2TXLYmw2DK5kX1VnTleT3LXvnIWE5rOyzcMdQ5knbpTfn9n8EukdZ+GoQAv55Qg3HVfoGzaoeiYJYyEI8hYTVPTnW9Fqs6bWwnXwD1LyJjwMvjOqCer9KOL8wle3KMVt8OVeSzQexFbhuc5YX22IoxT8jRXGlF3hWuOKgqEFE20v99hsKYCiDp1DFcg5CqGMXOfKCreQbZkHgNOEdK5aMKzm81OT0Kj+nV/up9g3+oqRtOepymQXitqTPGrmNMaCM33FcSYNf5dRqH3HbJVJ4lNE+UmNgWHG5bXOMrUlnL8UehJREdYXTa/wsrvSGQ/cZKTm81ODuo6rGp76qYGVPjkfa0jQn9jbJE7bLttG6CngVKuVI4rZLSBM82JJiRU8OMdxExyI40ouFCGjePCNttHsWo1C5R7rUcTm2wsflMyL9q8+Np/Z1ZV12Z9xB3bcdiSwtmeGHfIvRZ0l6B3x1TUV6Gd+X5x4vwoum7cy6xAbM3Sk3VV48uWrQ/LB3Gl1TeLY9Q7flfYiGLseRzfvgxkLSliSdfKDku4jAm36hqQoib83Oihhcc1DJO2K1MJy4nLe0kzd70yNXWAmmrmABf9mZ2reGNJD89anh7MN8gRSsQnXgR8VyOb3KT0jaPN452O3sOpLeUUaKipGwXXambW8u1BhJ2i73H1PF1JBnpqv5r8BoWjFWFOGJ8IxSk10ZhxW9ueIvcCQE7MzYbElZ5AaUte2CJcf2tS2QsF3i1h5B+sFBZZw7KUzEUGB8SSEG9JLGipufjCqH1BkBJM5rIjzApBnOCBkrBcOmEEqhq4KfLSzjgWOrOKxk8BIMw9fgvem1HLpzzrDdIl31RvbYxzpUaDODrnUkk4Ma5zUEOKTU4IhSgz8fWcmPCsLydttynr3q5qzHWrl/Z8Lb42eYeygCNNVbGEcV0BAy+OrMsa++vq9U+1ROqPTx1ZkRfnhQKZMGDH+7gCPluMz6fiRETJXNCYuenIsqoDvr0prMr/I1Rgrdu1dOqaX33CaOqzD7u231fvXtdRccybEVPi6cFKLWp6IgOLUhwpEVeYtxLBu35YmoClHN+2L1IyWm6u0IMFaOrTA5vtIctP6NKyHtuCwsNZgeGpv/TBVweJnJVbOjfH9+iedYHP2yUYmd10SFqYIjuagpSH1A26d0NSE4uz7A2fUBtLzfed0ZDRw0Dt/OcKRsSWoU69hyvV0PpgS1MZVnPxIWlZucUx+gyje4/sn8KOcHmyLcd2zVnmveIWGBIaNFH1rawcMtKc/TXuweriRoKNT5VGK2ZEGJwROLq7HzK5q/E7zYZXHKM7tYWGIwJ+LNEP7L9iQIqPF5cTKHlBr4FcEnp4aZFtLIuRJFeMPAAu/fBf652+IjL7byickhdqS8pQiVfKxSQFOYEVKJagoPtabpyjrccVQVH6jz86VXu1iXsFhcabKiN8f2lLfMgcwHA86LGpTogoQtuXlTnNiHJhEesiiQ5Up0RfDDtX3cuL6PgKagK7AtbnmiJUf4HBXeipQcWm7iUwSlhoKpCL46O8pxFSau3POstzfn+Nqr7d4ul4U0h9bD/Ja2Sj6U/ZHFdRxTWPAX+PzKOE+19CERbI7tvWyBKmBGSOf9tX5sCVuSXkTozUdUUpcf7y/UhZs2xfnv9X1s782xsMrH4aUGb8Ys0o7XUGaFdXZnHO7dlkTVBYeWmpxW7e1W+VpPlifaMl6jG658Cl9lRXBCdZAnjy++5mvOlRiK4Nq1ffzirRitCZu5pQadOXfPEpHFkN4qimfWBsi53tYcAH9cVElA8z6qw1zJb7dnue6N3TSnvO1AoMi7wHuAEsObUPvaafVMDe49GlB4x7dvT/LNVd3sHPjBk55j+VOTQ/0W/23bEnusoHzAZLmh8B9zSlhcafb75QSekCjI/jild5pB4nLCs+3oeGtz9q/xipdJRYFTqv2cWGnyaneWpGLy2NHDx2bsK8912rzvmWYOKTOZE9axJfzisHKyjkQI7yuiKSARBIT0RnRG4Y2E5LcbuujMumyIe+ICEFAVZoa9PXAun11CU0DDJ9z+pSrv73BZtquXjQmb7Unbc15KCGrCc17qnn/h6nkl3lyPYcjYDj5N5dr1cX69sZfmmEVdROfwUoMNcZvunLeNB3nTe3JQY3ZYRxOCh3alOKTUIKwKrjm4nCPKDDT25LHA73Za/NdrrXTmF7sO6AofnxQc1M3807Ykfk2gCslDJzRwYvneK6pduznHb9e2sz2xd8NT88O2H6gN4EjJt+eXIgSEVPaatpC1HWKuQqUheLg1wz3bYmxJOf3iMjOkYagKNywsoyvroikCIy9+kx9pZkfSLtoe+3EljSGdo8tNJkd9XDdvZMs5bbskXagwFC57vYf7tsfpHGG2OxKihsJZdQGyruTWRRVYEqJjXFXu2xvS3LC6nUxOUh3S+NTkEM1pu7+r4Ei4Y1uCEp+KArx8WgMzgnt1JPqxHJceRwzy7xiKoNty+cnaXpz88WsOLkPk6yn5j4hEEFZdtNEmgb7DDBKXrCP52LJuHt+V8FamHyIu76/zc1y5SXU0xMfr9q6Y7wS249KSA79SmDfiBeq9HVwp6bE9c2XgimAiH5HoIijVBlg8+X5nznZIouK6e0aQBl6nCG/x5cgY85e2HHbbCjUmPLE7x/9s7GFryqEz69Ke9sRFFTA1pDE/YiCAHx5cTqUpyElBtZ4fHi9CxnZotxRU6RLUBa0Zl1+s7x3UQL9zkFfxLAmNPlE0ajNjO3TYCkIWH7/QhOcDkEDJgC1URiJnO/RJFel6iywp+Y+EiktEH/y1PuP53TzRlhrWB9GP9Mq+Iahx0fRyfjR37OuPxHMOvY5Xt0ZCAH5NQUgvzGA8ZG2HtpygwhRsSjjctTVGj+UO8kP86OByMq63L1SD6S0IP14k0GN5FjswaFub/232CqLryDj0Od52EwPFBeF1B0xNwSdtAvrYFmmaoDg526HNVkG6OFL2L/zEgP2qJYI6c9/KV0pJuyVQBzSgSmPf0hoPAyfajZcjn2zl9Z7c6EGIrqQ6oDErrDO71M9vD9l7A7R/JRzXpctRQLrsieGWVI5TsP7d2EtcxsqEsLwN3kGP/L8iD7SkWBlzcKTg/GqVg8u9BauHYruSK96I80x7CilhXV9mTP5KkV/FrsmvcvqkMm6aH/g/X6b/juyzuEwwwXB8fHkfTzXHcJHUBgxqAjqxvE/Jcwh43TtTFazsTNFVZE3akVCF93GbX1XKkmMj/fsuT/CvxYS4TPCO86GlPdy3vbegIyC8HQL2qmj5nQbHsoi5KDgp89X1lNowfz26xJvNPGG1/EsyIfkTvOMEggaVPsVb3U3xxmz3Eha838YiLJBfYMpQmBLWmRXRmV8dImLk15mdEJZ/SSbEZYJ3nO9MVpkeDTDSHnTjIh9fVeVTCKowp6aUKyd5o0wTfr9/XSbEZYJ3FCkl06I+zmgIUlZYsX4fEXgBIaoqqDS9pSEaKkr5/XyT2oD+rs/HmWB8TIjLBO8o/ZaEqqEJiSpHXvR6OAQgLZdSv8rhZQa6gLryMu5cYFJmeqvsT1gt/9pMOHQn2C9s7ktz806LP23uY3fCQmjjmPVle0tNLqjwcUylwe60TSBSwk2zNG8/n7cRSzPBu8eEuEzwjlNo/I93wx/X7+YfbRn6xrDvdCEsd16ZgaEI3lvjp8IQWGaILzYIQroX5TshLP8eTIjLBPuNDX1Zbm+DR7d18npXDtMQZO381On+cWoPRRPespkITqr24VdgVmmAsN/k9KhDKD8yNNEV+vdhQlwm2C8ULIxNsSy/a5U80xxjZVcSiWBuVCduebsQCOEtlbExbnPFzAiagFllQVxV4+JqMLXBW59M8O/DhLhMsN8Y2IVZ15PmvzbbNOkuPmnTnnUpM1RUJJYEn2kyO6yTReHzTXvWppkQlX9fJsRlgv3OQJHpzVj8dIeNLz97Gwl+RXLplOCQiyaC4/7dmRCXCd41JqyQA4sJt/sE7xoTwnJgMSEuY+R/07z737z3BPvOgf7eJrpFgNXaikgmB/fxBQjDWw3OLS1FC4YKa2b9r2DtakGxcggpcGtq0HxvcyuXcSKlxN26BTQNqShoDY1DTzmgsJp3IjJZlEgYRVVxoiW4ySRKx26EruOUlqFH9n0H0v8LTIgLsOOQ+aS3bgY7v7+R6yJ0A33aNNTaGsoOP4LQ93449LJ3le0zpuOWhFCiUeq+/p/o7z1j6Cn7FevZp9lx+WUomrfEwZQVa4eecsAgrRxbG2vI7u4hcv7Z6PPmU/6pS4jfdw8dP78Rc/ZcyhefSPAb3x566QHFRLcI+nczFLruiYuiIG2L3MYNpJ9/nubrf8zuM9839LJ3l0gUraYGY8oURGnp0F/3K5n772fzme+FdAZ96jSMWXOGnnJA0fG1L+MAil+l794HyK1ehSsljm2jhkLoTU0ojQe2ZceEuHhI28WcMQv/EUehVVQhNA2EirlgAcaMGailpWTSSXquvGLope8awjA8y8pxkO9i+Lv1yku0//x6yFo4fb3eQX3/LM7+70J2wzpkNgNCoIZ0qn54Pcmn/kn8wb+RWbuZzKvLwHj7exr9u/Pu1dJ/UTr+42vkdmxFnzYdY958Gv7xBDN7UsyKZyj78teQjoPT0Ul62cvkduwcevm7RtNLL9H46JPU/uF29PcsGvrzfiPX10duw0aEoaJV19Bw30PU33730NMOKKwdO5GFLjQgbQunqwunvR3FByXvOwv/hR8detkBxwHvc2l+30mkli3DjaUInXs2td/9Aercef2/x378Y9p/fj1qZSXBE0+m+me/wtqxg7bPfQp7VwsYBvqkyUjbpuHeB72u1QA6f3It8T/eipNM4D/iSPRJkwkffSz+s8/tPye7fh2tn/gozu4OjFmzMefPR7qSqutvRGgaO889k/RzzyIzGervfYjQGZ6/Jf7AX+n59S+wdmxHnzQJfdIU/LNnU3LFfwLg9vTQee0P6P2f34CiMLM7SfPZ7ye3dTO++QsQukHl/7sS7aAF/XkpYC17mbYffI/k408jTJCOgxotIXrRx0HXqfrR9ez+r/8g9fQ/kbkc0nXRGxsRukHVVd/CWHRUvwO874Yb6PjljZiz5oCmIi2b1LPP4ps/n8mvvzH01v3s/s43SD72d2QyiTFrNmpZOeHzLyT03jPIvLGazm9cSWbNm0Q+ehFqVTXll38Np6ODzdMbCZx6GtKyqLv9L6iRKF03/ZT43Xfg9vaiN01G+H1UXPp5fO87c5CjPrPydXZfeQV26y6USARz3gIU06D6Fzf352vztEbU0jKEzwdSUnf7XfTdfhud1/0QoaqUfekKKq/7MQDpZS/T8a2rBqWnBgNU/fSX/eltmTkN33HHoFXVYO9qJvPKy6jV1agVFZR//JP4P3hefx7tNW/S8dMbyK54Hae3B33SFJTSEhr++lB/egXa/+vrpJ58AplKYs6Zj1JSQtn5F2K+94x3ZXDigBeXLbOnYLW0gJQ0PvQogZNO6f+t57bf0XHFVzBmzSF89rmY8+cTOPZ4NpaXYkyfgj5rFk57O9l1a70YDkVhxq4uen7zS4Sh03f7n8ht2oh50AJAkl3zJlpdHebceQTffxaBo4+l9ZMfJbdhI/rUKSglpeRWrcLNZggsPgGEoP4vf2P74qOw3noLoWk0Pv40uQ3r6bn5l2ReXYYxdx5qZRW5Deuxtm9D8fsJnHwqDfc9iL2rhZYPn09mxWvoTZMgm0OfPZvcxo3Yu1rwHbEIrbyciq9fhbnoqEHl4rz+Gh23/Jbk449id7RjzJyNOXceQtcRoTCJB/6KG49jzJqDWu41tMyry3B6exGKoP5//kjwggsBiP/sZ+z+5X+jVVWTXb8OmU2DomJOnsLkNzYMui9A909voOfXv8Dp7cFccDCKYZJdtxanuwshFKpv+g3mvLn0/uEW+u64HYTAv+gomh5/mo1RH+aChSAESkmUxoceY8dJx5Je9grGzNnok5rIrF6F096OUFUqfvIzyj77eVLLX6P7e98i+dzz6JMa0adOw25uJrdpA0JVUUpKmb61BYDNU5vwn3gCSigMtk3Ft79H321/oOunP0GrqqLsq1/Hd/BCun78IxKPPzFiep3XXUPPT29ErazATSQxZs3CTSXJbdiAEApqIEjJlVdRdtmXiD/6d1o/fB5KJIIxdz5Il+yqVUjXIfKhC0FCza//h87rr6Xvdzfj9PbhO/hghK6TXbMGp7cHIRRqrv4Rka9+bb8LzAHfLerfy0IIWi/5JFvmTGPLrClsnTudziu+CkLgxHrJrHyd9KvLaP38JfgWLkCtLOyvK1BDYaTjIHM5ABIPPUDPTT8jt2kDTk8C6TqgqSiBIG5PL5lly7A3b8aN9ZFduxahaThd3QhNQ9o2iukju3Il2RUrPEsom0OfNg3joPlotbVk175JbvNbqA31CJ+JTKcxD1pA6MyzvNgK26Lz6m+jREvIrFgOCPTpM9BmzABd96qUopB5fTmJfz6Bu7O5vzgKKJaFUlODPnMWakkpkQs/glbfgBuPE7vzduzW3TixdH6ETQFF9cogk0MYPtq/9iUSzz1D4qWl9D31GNnNO7F7e4he8lkCJ52Kk7CQ3d1DbwtA362/QwkEMCZPReg60nFwEwmcpI02qYnY3+4mt3UL4bPPA8dBq6pGnzyZrQfNxpy/wOuuSEnDPQ+w49TFpJa8iJtykFbO293PdZEZGxGJ0PvzG0g99QQkE2RWrcScPQs1WgKODbkcbtJGSok5dy67LrqQ9ssvw0nFid97N24yiQgEPH+YrmNMmYr/iCMxps9AupLUkheKpocQXnoXf5jsG6uQtuVNkQgGPH+foqCGw0jHxurqQA1HyLy6jF3nnYUTy+Imkt70CDU/qTOTIX7fvcT+eg8IQd+tv0cJhDAmTwFdR9oObnJP+cWffpzEXX/er8LCgSwu/eaaqiCzFm7Kwm5vw2reSW77NpxEgsCpp1H65a9izpyFEgkTPOU03FQSJRzGmDmL+j/9BX3yZJxYDJmzkJbtJVlXhz5rNrguWm0ZMp2i8ltXU/HN7yBzOdxUyvsKqyq4Lq6Vwzz4YLT6eqZt2enFlKTTuPE4nT/4HlbLTnwLDyGw+GTar7yC3lt/h93aipvNETr6WJr++SxVX/s6IhJBpnJk164lveyV/INKlECQ7KpVoGnU/vhGpqx4E71pEnptHca0GSjhUH+5FBCLjiJ6xCJkNoPd1knsL3ei1dailFcgMxmil1xC9OMfo/6+B6n7w5+ou+k3TH9rB8EzzkC6DlYijuzqgvY27M7dGFPqCRxzLG4sRvCII5mTydDw8vKht6XlYxeQ3bgRc+Gh+BefQPWNN9H0xDPU/f6PBN6zEGvbNnJr1pBduYLgae+l5je34CYTJP/5OEo06jU4Kam/+290/ewG0q+8TOQjHyH66Yup+/Pd1P3+T0zbsJXQ8SeCpiF8PnZ/8z9pv/wylEiEwGnvJfzhj9L4yBM0Pv4UpZddisxmya1bR/rFJaRfWwa5HNK2iJxzHtXX3UDqhefpu/2PpF9dgd3SQt+tv6P10k+glpUVTc9NpfrTyyxbhrQs7OZmpJRUfOHLTH7uZXxHHo3MZHDjOeJ/vZfOa69Bq6+n9KtfouzKq2h8+DEabruDhj/fgwTcVBKZSrHj9BOxdm7HPOxw/MefQM3PfkXTP5+l9pZb8R86H2vbNjJr1+K8sXpo0b/jHLDiIoCO73wDq7WV0DnnUvrFy1CiUWTG21xdaBpKtATF5yNywUeo/e2tqNEo1ratZFa+TvLJx9l18Uewd+wAJIETT8R/3LGgqZ61IR1CHzwHvb4Ja+tWWi/7LH1/ug1j1mzKvnIF1T//Fdl169CqqvEfsYjUM0+TeOQRdp75XozpM9AnTWLaWzuwO9pBSvru/gsylyW3cQN2SysoCuXvP5vyH14PgHHMcZQcdwJK0AQkwmeiBIMIXce3aBHGjBnU/uRnaDNnowSDKEYI89DD8B97HGr54E3cC8IrHZfs6lWgeEeCJ55CdtXrACQffQS1ugatqgq1qhqlthbhD6C6LjKT8aw4RcHp7SW3YQNOZweZ1asI1dZS+o1vI0wTvbFpwF09MkuXIDSV5JNPEL/3btouu4Tm886i4wffI7dxPWp5BVp1DSLkCaJ50MG4PT24fX0ooRBaZRX1f30Qra6OxN8fBkUh8fijCJ8fs6wMpaQUYZhU3nM3k//+T5qefJ7ACSeT27oVu62V2B1/pPfXv6D57DPY9amLSDzi+dHUSu85cxs34qbT4Er0xkmgquTWvImMxxAKBM84E3PhoVhbtmC3txVPzzS99CoqcTo6UAwTxTCpu/qH+N9/FgCGEUCJhNGn1GHt3EZ23RqslhYyK17HX1qGME2U6hr8p5zC1KWvMfnVVUx+dRXZVSsRQpB84lHi991N6+c+TfO5H6Dzh98n99amPeVXsv/DGQ5YcQFIL12CEILU888ggaY772X6hreY+uJrNN3/CFXf+DZln/g04Q9dSOb119h59vuxtmzBzaRxOjvJbdqA//jF4Lpk31iNWlKKUFRqfn0LjQ8/QfC09yJME6crgRIM4KZT2K27SD37LPH7/0rkgg9T+6e7UPwBnK4EbncXSihEbuMGhM9PxzevIr3kBdxUGrcvSeC4xWjVNSiRMFp5BeaMGf3Pkt2wnt577kIEg4Q+eC5qRSXtX/0ibiZDZsUKlNIy9GnTAdj9k2uxd20l+ejfceJxhg4sF8xlN5MDKdGbGtEaGjDmzsXaug0Aa3sb5V/6CiLg7dHs5l13Ag21qgp96lSUYBA0FTeRwk3mMIMlBK/6FkIduMnsYKTldRvceAyns4P00ldIPPww2TdX46ayKKEwSiSCWlqGG4ux46RjPedneTnp114lu3E9WlU1MpfzhN91cft6iZ5wErK+of++ZkUl+tx5qKVlaFXV4NjIXA6nvZ3cls0kHn6U1HPPYnd0IBQFJRxBCUeQ2SzGlKmYs2ZDfp/rzJo3sTt2gybQauvQ6htASi8PxdJTVZRwGFQVaVuYhxyCedhhmIe9p78chM+PueAQwhd8BCUQwm7eCZaLGSol+Pkv9p+HEBgHLcCcMxdzztz+Y25fr1d+S14i8cgjZNe8iUznUEJhRDSKmkruSWM/cUCLS27TRq8/39VDaN58zMUnok2dhnHYYegHL0SdPAVRW4fQdOwVq3C7e1DDEfyHL2JGR4y6P91J6vlnQQjs1i6qfng97V++jF0Xf5i2r3yBzmuuJnrxJ5gjJWVf/ApCVXFjfTjxHrqu+wFtl11K17U/wG5tZVYywZTlb6DV1uLEY7ipBKmXl2Bt3YpaWoI+uR7fIYd5FReJm0xim2b/szibNpBatxY3Hiez/DXUyipSS14AQMb6KP/KFch8Hz1979046TROLEVo2nScIaNFBaHwRiwqCRx/AsaMWWDZ6FOngqZR+qXPE7t3z5C0IgSdv/0ViSVPYW3fhRuPeV/80jL0SY0ETz0R/zFHopjmiI5ENVrS7zOp/f2fmd7SxszeJJGPfAwlYGLvasa/6Eh8Bx3M9hOOxs1kwHYQpom0cuhNjXR89xsIXceYPRuhqghNx3/mWSiKggC6fvULWk48hq2LDiG99EXP8vIHwXXxH3s8M7sSTG/ZReMjj6NGokjHIbdpAzU334Lw+fAfcxy+RUehBMMAyEQKJRBAq6lBaJp3T9ME1yV48ml7p2dZZNevw1yQd7auXQPBIGQzAHQ//ADxZ58g/fJSnNZdmAsWoJSWYsycjr5gLn3PPOXd17LovOhCdpxyMjvzQZ5KOJIfIhfU/flepre0MrM3QfjcD6H4DeyWZgJ1dZj/zxtR3J8c0OIiM9m8+Q6+E08BIYb9oqrREMJn4iYToKn0/OKndN/0M7KrVnqV8shD6fvzH7E6dpN+8QV6f/MbrM2bSb/yEr23/Z7EPx4ms2oVTjyOvasFJVpCdu0a4g/8HSceo/d3vyX+yEPEH7gfmXWxtm3D6e3FzWYwZs3GmDUbpItMJsFxcXqS9N17F93XXM3uz1/Crm9+B3tHK9g21s7tBI5bTG7zJnAlUoL/mOP611Rx4wkEAjUcwHfM8aj5Bl9AEYL0pk103Xgt1s7tXvfNZ4KUqDU1YNuknn6S9MtL6fvv6+n41MV0fObj9Pzn1zEWHEL47A9Qdd2NSNel+1c3Ybe04CQT6Go+EnrAvYYiE3FQFNyERfKZJ4j/9W66f3ItmVdeRloWTneS1EtL6f7Fz8isXAM5F2H4qPjO9xGqRnbDBnp++xuvgeWdo27SovWST9Bz7ffpuvwL9Hz3m8SXvUJ2/TqsZa+i5rJI08RN29gtzfTeegt9d/yJ3v/5DW4+cNDp6iR2719ASpJPP+lZHtL1Mu0LYMyZi//oY9GqqsB1AYGb9t7FXulJidvbg9Ox20u7s4vSMz+InJa3RJ9/FiedwunLYEye6vnHGhuxW5pJvPA8mb/cSeynP6H9nA/Q/eQ/cbMJnJ4O71rH8crRtkk88Q9i99xF9w0/Jrv2TWTBv1degxYO7/etWQ5ocQEwpk7DmDkLclkYoeKrqSRKTQ3GnLm4iQTpV14mu2EdbsZBa2hArakl8+YqjBkzPQ+9BfqUKWRWrqTnlz/H2tVC8LTTUKtrCMw6mLJzzkepq0MYoPj99N32B+J/uwdz3nwCi4/B6YgROP4ElFCI7Ib1YBjIrk6qf/LfaMFStGkNyFyOvgf/Rmrtm/hmT8M8bAGqFmTKM0vxH/4ekGDOnoMxoPsEnlPFXHgI/mOORfF5kaRDn1vbsI5cVzcyCyTiBC7+FMLvp+J9Z+LmbJTSUrIb1tN9559JvrWR1KaNqFOmYMyahT5zFv73LMp3TbbjZlzMQBD90i8Mucve1N1+F/Rl8B95KLmNG+i7/TYSTz6OWlWF0HXMeTOQ6TTp117Bf9RhhC/8EJNfWU7wpFPwLToSp7WV4Mmn0v3zG6m+9gZkJoNv4TxymzbSe/9fSa5bi3nkUYhoCZVHn0jwc5/D/9GLKD/oMNSacrSmJmJ3/pn4ffdgt7Wiz56Nm7Kou/0u0ktfBMfB3t6MOXsu+qTJJJ95mtyalWRXr8LN5RDJBOHzLyB0xLFeerW1RdKzqfvzX8iuXo10HIShEzzrHLR8VK+1bTvSdTGmN6LPnUv5ld8gUFqONE0UXSP58ot03X0nmZ4ujClT0Kqr0aprAGj4nz8gXBdcSe6tjaSWPE/s3ru97rzrUnnkYnxXXgmw35fAOKDFxY3HUErLPOeam/8KDccHzqHuA2cjysuQVg4pQK+pYfKddyCCQbAspOMSWXQk9ddcx5RHHsI/fSZOXy926y7Uigq0KdOoPeuDVN1zD/7PfJb6T11C7VXfQAoFu6UFmcthzJ6NMWUqUx78G+a0GQjdwG7dTdnUaci6BpSycuqXvkjlMcchhcDp3I0aiWLMm0/54hNofH05akMD7vYdoBuolZWo4eigR3F2tqJWVaHW16MNN5Wgpwe7uxthCjSp4p89x4snufTzTP3j7Ziz54DrDXGq0ShqZSXa1GlEDnsPZe//AMbkKThr1+Akk+BT8Fc3YtY3jPq19B1/ApNefIHAnLm42azno/D5UerqqP7qFVR88lNIw0CmUmhTpuKbNAm1ogISCdT6BoRp4jvkMGQqhbngYKb8458YkyYhHRunpxslGkWbPJmmT3+GkvvuQ/X7UX1+Su67j8ZLPoeIlmC3tyFzWdTaWozGJqb+4++Ezzkft7vb2+QtYBA+5zwAZEszGDpWd5JQLotYeBgA1YX0IpHB6TVNYuqT/yR89nnIvN9DCuGNrOVxd7aCYSBKStBavDCBsnvup+nzX0RUVuEmk2DbaPX16LW1VH3hcio/5/lhzFNOo+6W22i46WaMxiasrVuQdg7fEUcQOuVUgn/4PXp5+ajv4Z3ggA6ii998M1o4gJrNwXkfwogOboQFCiuo2YkE7j13Yes6ajiME4kSOOkUUrfeglJWjrAszPO9wDGA5LKXEa8tQ+YbuQ7Yi47CrK3rP8dOp3Fu/R22qqKEQqgVlUhFwTz1dKzXXyP3ysvQEyNw1VUIRcF1XRRFIf3WRpTnnsVGopaVo0ejWE2T8U33rJRcXx/2b36DMmUSUlXwD8hX7I9/xIwE0RQF65jj8VUMHi0CSO/YjvLg/VhZG3f6VCIDIooBco/9A3t3O7iuNwSsKKjxOOL8C9B8fgASb6xGffpJ3HQO97hjCB9z3KA0ilHwx2RefQW5bi2uY6OEI2jZDJx1Lq6VQ/ztPnKOjVFZhdU4ieB7jiCXSKA8/SSZHTvwH3EErgTtPUcgFIX000/Czh24roNWXolmW7inno4ejvQ3MiEEVjyOeOhvZLM5FNMbbXPDEfwnn4p0XTJ/uw+ntQ2RSmN86YvowRCZtzYhn3sGt6UN7bOXYtbU9r8jKx5HPPg3srni6aVuuRk3a6Ok96QHEHvsH2gb13tLOZxyOsFZswGKpudESwicePJe5QfQ+umLyby5GjceQ29oRAmFabj/7+/aioAHrLgUcyoWO1ZgvC/ElRJlmPMLv410v2IUzh8tbSHEsOkWu+fQY8Wetdix4ZD584fmcaR8D2Q89wL6G3MxRkpr4G8jnlekzBjmeQrpjJjeML8NV24DBbAYw+Xvf5sDVlwmmGCC/UtxuZ9gggkmeJtMiMsEE0ywX5gQlwkmmGC/MCEuE0wwwX5hQlwmmGCC/cL/B7tWwbtmpXXvAAAAAElFTkSuQmCC";
    // doc.addImage(Image, "PNG", 10, 12, 40, 12);
     doc.setFontSize(22);
     doc.setFont("Arial", "bold");
     doc.text("Allenger", 10, y+10);
          
             doc.setFontSize(7);
             doc.setFont("Arial", "normal");

             //Get Part No Information
             
             //Get Part No Information

            //Left Side Content
               doc.text("Inspection Lot No.", 10, y+30);
               doc.text(`${value[0].InspectionLot|| ""}`, 60, y+30);
                doc.text("Production Order NO.", 10, y+35);
                doc.text(`${value[0].ManufacturingOrder|| ""}`,60,y+35);
                //doc.text("Production Order Type (MTS/MTO)", 10, y+35);
              // doc.text(`${productionData[0].ManufacturingOrderType}`, 60, y+35);
               doc.text("Serial Number ", 10, y+40);
               doc.text(`${value[0].SerialBatchNumber|| ""}`, 60, y+40);
               doc.text("Date of Testing (Inspection start Date)", 10, y+45);
              //doc.text(`${value[0].DateOfT || ""}`, 60, y+45);
              const formattedDate = value[0].PostDate
            ? new Date(value[0].DateOfT).toLocaleDateString("en-GB")
            : "";

            doc.text(value[0].PostDate, 60, y + 45);


             
                doc.text("Part code ", 120, y+30);
              doc.text(`${value[0].Material|| ""}`, 145, y+30);
              

               doc.text("Machine Model", 120, y+35);
               doc.text(`${PartData[0].MachineModel|| ""}`, 145, y+35);


               doc.text("Machine Series", 10, y+50);
               doc.text(`${PartData[0].MachineSeries|| ""}`, 60, y+50);

               doc.text("Manufacturing code ", 120, y+40);
               doc.text(`${PartData[0].ManufacturingCode|| ""}`, 145, y+40);
               doc.text("Manufacturing ", 120, y+45);
               doc.text("code Revision", 120, y+48);
               doc.text(`${PartData[0].ManufacturingCodeRevision || ""}`, 145, y+45);
               doc.text("If code is Desired ", 120, y+53);
               doc.text("then give Details:- ", 120, y+56);
               doc.text(`${value[0].ReasonforDesire|| ""}`, 145, y+53);
                //doc.line(5, y, 5, y+70);

                  doc.text("Part Description", 10, y+60);
              // doc.text(`${PartData[0].PartCodeDescription|| ""}`, 145, y+55);
debugger
             const desireDetails = PartData[0].YY1_ProductDetailDescr_PRD || "";
        const desireLines = doc.splitTextToSize(desireDetails, 150); // Adjust width as needed

        let desireY = y + 60 ;

        desireLines.forEach((line) => {
            doc.text(line, 50, desireY);
            desireY += 4; // Line spacing
            y=y+4;
        });
        doc.line(doc.internal.pageSize.getWidth() - 5, 10, doc.internal.pageSize.getWidth() - 5, y+70);
         doc.line(5, 10, 5, y+70);
          

    // ✅ RETURN WHERE NEXT SECTION SHOULD START
    return y+70;

},


       PageHeader: function (doc, value, startY) {

    const pageWidth = doc.internal.pageSize.getWidth();

    

    // ---- Table Header ----
   let Py = startY;
    doc.line(5, Py, pageWidth - 5, Py);

    Py += 4;
    doc.text("Sr No.", 8, Py);
                doc.text("Inspection Parameter", 18, Py);
                doc.text("Characteristics", 92, Py);
                doc.text("Range", 110, Py);
                doc.text("Device Group", 125, Py);
                doc.text("Observed Value", 165, Py);
                doc.text("UOM", 183, Py);
             
                doc.text("Status", 194, Py);
                
            doc.line(5, Py-4, 5, Py-5 +  12);
            doc.line(17, Py-4, 17, Py-5 +  12); // Vertical line between "Material" and "Quantity"
            doc.line(90, Py-4 , 90, Py-5 +  12 ); // Vertical line between "Quantity" and "UOM"
            doc.line(107, Py-4 , 107, Py-5 +  12);
            doc.line(124, Py-4 , 124, Py-5 +  12 );
            doc.line(160, Py-4 , 160, Py-5 +  12 );
            doc.line(182, Py-4 , 182, Py-5 +  12 );
             doc.line(193, Py-4 , 193, Py-5 +  12 );
             doc.line(doc.internal.pageSize.getWidth() - 5, Py-4, doc.internal.pageSize.getWidth() - 5, Py-5 +  12);
           

    Py += 7;
    doc.line(5, Py, pageWidth - 5, Py);

    // ✅ RETURN START Y FOR LINE ITEMS
    return Py + 3;
},
  LineSection: function (doc, value, startY) {

   // resetFont(doc);
    var LineY = startY;
    var pageHeight = doc.internal.pageSize.getHeight();
    var bottomMargin = 30;
    var textLineHeight = 3;
    var minRowHeight = 4;

    // ============================================================
    // STEP 1: Group data by ParentParameterName
    // Result: [ { parent: "...", children: [ {...}, {...} ] }, ... ]
    // ============================================================
    var groups = [];
var parentMap = {};
var parentOrder = [];

for (var i = 0; i < value.length; i++) {
    var row = value[i];
    var parentKey = row.ParentParameterName || row.ParameterName || "Unknown";

    if (!parentMap[parentKey]) {
        parentMap[parentKey] = {
            parent: parentKey,
            parentRow: row,
            children: [],
            childKeys: {}          // NEW: track dedup keys for this parent's children
        };
        parentOrder.push(parentKey);
    }

    if (row.ParameterName && row.ParameterName !== row.ParentParameterName) {
        // Use ParameterCode if available (more reliable than name), else fall back to name
        var childKey = row.ParameterCode || row.ParameterName;

        if (!parentMap[parentKey].childKeys[childKey]) {
            parentMap[parentKey].childKeys[childKey] = true;
            parentMap[parentKey].children.push(row);
        }
    }
}

for (var p = 0; p < parentOrder.length; p++) {
    groups.push(parentMap[parentOrder[p]]);
}

    // ============================================================
    // STEP 2: Render each group
    // ============================================================
    var parentCounter = 0;

    for (var g = 0; g < groups.length; g++) {
        var group = groups[g];
        var parentRow = group.parentRow;
        parentCounter++;

        // ---- PARENT ROW ----
        var parentText = (group.parent);
        var parentDescLines = doc.splitTextToSize(parentText, 60);

        var parentDeviceText = (parentRow.DeviceGroup || "");
        var parentDeviceLines = doc.splitTextToSize(parentDeviceText, 40);

        var parentRowHeight = Math.max(
            parentDescLines.length * textLineHeight,
            parentDeviceLines.length * textLineHeight,
            minRowHeight
        );

        // Page break check for parent
        if (LineY + parentRowHeight > pageHeight - bottomMargin) {
            doc.addPage();
           // resetFont(doc);
            LineY = this.PageHeader(doc, value, 10);
        }

        var rowStartY = LineY;

        // Sr. No. — bold style for parent (just the number, e.g. "1")
        doc.text(parentCounter.toString(), 8, rowStartY);

        // Parameter Name (parent)
        parentDescLines.forEach(function (line, idx) {
            doc.text(line, 21, rowStartY + idx * textLineHeight);
        });

        // Device Group
        parentDeviceLines.forEach(function (line, idx) {
            doc.text(line, 125, rowStartY + idx * textLineHeight);
        });
debugger
        // Other columns for parent row
       const getValue = (value) => (value?.toString().trim() || "");

doc.text(getValue(parentRow.Attribute),    95,  rowStartY);
doc.text(getValue(parentRow.Lowervalue),   108, rowStartY);
doc.text("-",                              115, rowStartY);
doc.text(getValue(parentRow.Uppervalue),   116, rowStartY);
doc.text(getValue(parentRow.Observation),  162, rowStartY);
doc.text(getValue(parentRow.UOM),          183, rowStartY);
doc.text(getValue(parentRow.Status),       194, rowStartY);


        // Horizontal line
        doc.line(5, rowStartY + parentRowHeight + 2,
            doc.internal.pageSize.getWidth() - 5,
            rowStartY + parentRowHeight + 2);

        // Vertical lines
        [5, 17, 90, 107, 124, 160, 182, 193,
            doc.internal.pageSize.getWidth() - 5
        ].forEach(function (x) {
            doc.line(x, rowStartY - 4, x, rowStartY + parentRowHeight + 2);
        });

        LineY += parentRowHeight + 6;

        // ---- CHILD ROWS ----
        for (var c = 0; c < group.children.length; c++) {
            var child = group.children[c];
            var childSrNo = parentCounter + "." + (c + 1);  // e.g. 1.1, 1.2

            var childText = (child.ParameterName || "");
            var childDescLines = doc.splitTextToSize(childText, 55); // slightly narrower for indent

            var childDeviceText = (child.DeviceGroup || "");
            var childDeviceLines = doc.splitTextToSize(childDeviceText, 40);

            var childRowHeight = Math.max(
                childDescLines.length * textLineHeight,
                childDeviceLines.length * textLineHeight,
                minRowHeight
            );

            // Page break check for child
            if (LineY + childRowHeight > pageHeight - bottomMargin) {
                doc.addPage();
               // resetFont(doc);
                LineY = this.PageHeader(doc, value, 10);
            }

            var childRowStartY = LineY;

            // Sr. No. for child (e.g. "1.1")
            doc.text(childSrNo, 8, childRowStartY);

            // ParameterName indented slightly more than parent
            childDescLines.forEach(function (line, idx) {
                doc.text(line, 23, childRowStartY + idx * textLineHeight); // 23 vs 21 for indent
            });

            // Device Group
            childDeviceLines.forEach(function (line, idx) {
                doc.text(line, 125, childRowStartY + idx * textLineHeight);
            });

            // Other columns
            doc.text((child.Attribute),    95,  childRowStartY);
            doc.text((child.Lowervalue),   108, childRowStartY);
            doc.text("-",                           115, childRowStartY);
            doc.text((child.Uppervalue),   116, childRowStartY);
            doc.text((child.Observation),  162, childRowStartY);
            doc.text((child.UOM),          183, childRowStartY);  // ✅ Ω → Ohm
            doc.text((child.Status),       194, childRowStartY);

            // Horizontal line
            doc.line(5, childRowStartY + childRowHeight + 2,
                doc.internal.pageSize.getWidth() - 5,
                childRowStartY + childRowHeight + 2);

            // Vertical lines
            [5, 17, 90, 107, 124, 160, 182, 193,
                doc.internal.pageSize.getWidth() - 5
            ].forEach(function (x) {
                doc.line(x, childRowStartY - 4, x, childRowStartY + childRowHeight + 2);
            });

            LineY += childRowHeight + 6;
        }
    }

    return LineY;
},
 DeviceHeader: function (doc, value, startY) {

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const _remainingHeight = pageHeight - startY;

    let Py = startY;

    if (_remainingHeight > 40) {

        doc.line(5, Py, pageWidth - 5, Py);

        Py += 4;
        doc.text("Sr No.", 8, Py);
        doc.text("Device Group", 35, Py);
        doc.text("AMSL ID", 130, Py);
        doc.text("Serial Number", 175, Py);

        doc.line(5, Py - 4, 5, Py - 5 + 10);
        doc.line(17, Py - 4, 17, Py - 5 + 10);
        doc.line(99, Py - 4, 99, Py - 5 + 10);
        doc.line(170, Py - 4, 170, Py - 5 + 10);
        doc.line(pageWidth - 5, Py - 4, pageWidth - 5, Py - 5 + 10);

    } else {
        doc.addPage();
        return this.DeviceHeader(doc, value, 10); // ✅ FIX
    }

    Py += 7;
    doc.line(5, Py - 2, pageWidth - 5, Py - 2);

    return Py + 3;
},
 DeviceLineSection: function (doc, value11, startY,value111) {
debugger
    let LineY = startY;
    const oGMCModel = this.getView().getModel("DeviceList");
    //value
    const value = oGMCModel.getData().value;
    const pageHeight = doc.internal.pageSize.getHeight();
    const bottomMargin = 30;
    const textLineHeight = 3;
    const minRowHeight = 4;

    for (let i = 0; i < value11.length; i++) {//ItemCode
       
        const rowHeight = Math.max(
             textLineHeight,
            minRowHeight
        );
debugger;
        // ===== PAGE BREAK (CORRECT WAY) =====
        if (LineY + rowHeight > pageHeight - bottomMargin) {
            doc.addPage();
            LineY = this.DeviceHeader(doc, value, 10);
        }

        const rowStartY = LineY;

        doc.text((i + 1).toString(), 8, rowStartY);
        doc.text(`${(value11[i].DeviceGroup|| "" )}`, 35, rowStartY,);       
        doc.text(`${value11[i].DeviceGroupID || ""}`, 130, rowStartY);
          doc.text(`${value11[i].DSerial || ""}`, 175, rowStartY);
       
       

        doc.line(5, rowStartY + rowHeight + 2,
                 doc.internal.pageSize.getWidth() - 5,
                 rowStartY + rowHeight + 2);
                  // Vertical lines (grow with row)
        // -----------------------------
        [
            5,17,99, 170,doc.internal.pageSize.getWidth() - 5
        ].forEach(x => {
            doc.line(
                x,
                rowStartY - 6,
                x,
                rowStartY + rowHeight + 2
            );
        });


        LineY += rowHeight + 6;
    }
    debugger
doc.text("Remarks :", 15, LineY,); 
doc.text(`${(value111[0].TransferUDRemarks|| "" )}`, 35, LineY,); 
LineY +=  5;
    return LineY;
},              
        foooter:function(doc,value,productionData,Footer_Y)
        {
            let _footer=5;
             const pageWidth = doc.internal.pageSize.getWidth();
            const pageHeight = doc.internal.pageSize.getHeight();
            if (Footer_Y === undefined) {
             Footer_Y =_footer;
             }
            const _remaningHeight=pageHeight-Footer_Y;
            //let Py = Footer_Y;
    if(_remaningHeight>40)
    {
            debugger;
            let FooterY=Footer_Y;
   doc.line(5, FooterY-2 , doc.internal.pageSize.getWidth() - 5, FooterY-2);/// Horijontal line1
   doc.line(5, FooterY-2 ,  5, FooterY+47);/// vartical line left
   doc.line(doc.internal.pageSize.getWidth() - 5, FooterY-2 ,  doc.internal.pageSize.getWidth() - 5, FooterY+47);/// vartical Right
           // doc.setFont("Arial", "bold");
              doc.text("Machine / Material Prepared By :", 10, FooterY + 15);
                        
               doc.text("Name", 50, FooterY + 15);
               doc.text(`${(value[0].Employeeworker|| "" )}`, 65, FooterY + 15);

                doc.text("Signature", 100, FooterY + 15);
               doc.text("Date", 150, FooterY + 15);
debugger
let sdate="";
            //#region  GetDate formate
                    let date=productionData[0].MfgOrderCreationDate;
                    let millis = date.match(/\d+/);   // extract number
                        if (millis) {
                            sdate = new Date(parseInt(millis[0], 10));
                            console.log(date); // valid date
                        } else {
                           // console.error("Invalid SAP date format");
                        }
                //#endregion
                const dateOnly = new Date(sdate).toISOString().split('T')[0];
                 const MfgOrderCreationDate = dateOnly
                    ? new Date(dateOnly).toLocaleDateString("en-GB")
                    : "";

                  //  doc.text(UDPostingDate, 65, FooterY + 45);
            
                 doc.text(`${(MfgOrderCreationDate|| "" )}`, 165, FooterY + 15);

                 doc.text("Inspected By:-", 10, FooterY + 20);

             doc.text("Electrial Inspector-", 15, FooterY + 25);
              doc.text("Name", 50, FooterY + 25);
              doc.text(`${(value[0].ElectrialUserName || "" )}`, 65, FooterY + 25);
              
               doc.text("Signature", 100, FooterY + 25);
                doc.text("Date", 150, FooterY + 25);
                 //doc.text("Date", 150, FooterY + 25);
                 if (value[0].ElectrialDate != null && value[0].ElectrialDate != "")
                {
                        doc.text(
                new Date(value[0].ElectrialDate).toLocaleDateString('en-GB'),
                165,
                FooterY + 25
                );
             }

                 doc.text("Mechanical Inspector-", 15, FooterY + 35);
              doc.text("Name", 50, FooterY + 35);
              doc.text(`${(value[0].MechnicalUserName  || "")}`, 65, FooterY + 35);

               doc.text("Signature", 100, FooterY + 35);
                doc.text("Date", 150, FooterY + 35);
                debugger
                if (value[0].MechnicalDate != null && value[0].MechnicalDate != "")
                {
               doc.text(
                    new Date(value[0].MechnicalDate).toLocaleDateString('en-GB'),
                    165,
                    FooterY + 35
                    );
            }
                doc.text("Final Inspector-", 10, FooterY + 45);
              doc.text("Name", 50, FooterY + 45);
               doc.text(`${(value[0].InventoryTransferUserName  || "")}`, 65, FooterY + 45);
               doc.text("Signature", 100, FooterY + 45);
                doc.text("Date", 150, FooterY + 45);
                 //doc.text(`${(value[0].UDPostingDate  || "")}`, 65, FooterY + 45);

                 const InventoryTransferPostingDate = value[0].InventoryTransferPostingDate
                    ? new Date(value[0].InventoryTransferPostingDate).toLocaleDateString("en-GB")
                    : "";

                    doc.text(InventoryTransferPostingDate, 165, FooterY + 45);
                    doc.line(5, FooterY+47 , doc.internal.pageSize.getWidth() - 5, FooterY+47);
                   
                 //doc.line(5, FooterY+50 , doc.internal.pageSize.getWidth() - 5, FooterY+50);

                
                 doc.page = doc.internal.getNumberOfPages();
                
               

               
    }
    else
    {
             doc.addPage();
             Footer_Y=5
            this.foooter(doc, value,productionData, Footer_Y);   
    }
},
     
 });
});
